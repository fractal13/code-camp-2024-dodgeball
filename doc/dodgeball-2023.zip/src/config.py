# These are configurable parameters for your game
# Text Displayed in the title bar
TITLE = "Dodgeball"
# Size of the window
WIDTH = 600
HEIGHT = 480
# Number of frames per second
FRAME_RATE = 20

